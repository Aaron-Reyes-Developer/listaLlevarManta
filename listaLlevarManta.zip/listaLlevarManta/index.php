<?php

include('conexion.php');



// ELIMINAR
if (isset($_REQUEST['eliminar'])) {

    $id_cosa = $_REQUEST['eliminar'];

    $queryEliminar  = mysqli_query($conn, "DELETE FROM miscosas WHERE id_miscosas = '$id_cosa' ");

    header('Location: index.php');
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">


    <link rel="stylesheet" href="estiloIndex.css">
    <title>TODO</title>
</head>

<body>



    <div class="container mt-5">

        <h1>Lista para llevar a manta</h1> <button onclick="mostrarFormulario()" class="btn btn-primary">Mostrar
            Formulario</button>
        <hr>

        <form class="formulario formularioDesactivado" id="formulario">

            <div class="mb-3">
                <label for="nombre" class="form-label">Cosa que llevar*</label>
                <input type="text" class="form-control" name="nombre" id="nombre" placeholder="nombre de la cosa" required>
            </div>


            <div class="mb-3">
                <label for="comentario" class="form-label">Comentario (opcional) </label>
                <textarea class="form-control" name="comentario" id="comentario" rows="3"></textarea>
            </div>


            <div class="mb-3">
                <input type="submit" class="form-control btn btn-primary" id="cosa" value="Guardar">
            </div>
        </form>


        <ul id="ul">

            <?php
            $queryConsulta = mysqli_query($conn, "SELECT * FROM miscosas ORDER BY fecha DESC");

            while ($recorrerDatos = mysqli_fetch_array($queryConsulta)) {

                if ($recorrerDatos['completado'] == 1) {
            ?>
                    <li class="mb-3" style="color: green;"><b><?php echo $recorrerDatos['nombre'] ?></b> (<?php echo $recorrerDatos['comentario'] ?>) <a style="margin-left: 20PX;" href="?eliminar=<?php echo $recorrerDatos['id_miscosas'] ?>">......X......</a></li>

                <?php

                } else {

                ?>
                    <li class="mb-3" id="li<?php echo $recorrerDatos['id_miscosas'] ?>"><b><?php echo $recorrerDatos['nombre'] ?></b> (<?php echo $recorrerDatos['comentario'] ?>) <input onclick="completado(<?php echo $recorrerDatos['id_miscosas'] ?>)" id="<?php echo $recorrerDatos['id_miscosas'] ?>" type="checkbox" name="completado"> <a style="margin-left: 20PX;" href="?eliminar=<?php echo $recorrerDatos['id_miscosas'] ?>">......X......</a></li>

            <?php
                }
            }

            ?>
        </ul>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>



    <script>
        function mostrarFormulario() {
            document.getElementById('formulario').classList.toggle('formularioDesactivado')
        }



        var formulario = document.getElementById('formulario')
        var ul = document.getElementById('ul')

        // INSERTAR
        formulario.addEventListener('submit', function(e) {
            e.preventDefault()


            let formdata = new FormData(formulario)

            // INSERTAR COSA
            fetch('./insertarCosa.php', {
                    method: 'POST',
                    body: formdata
                })
                .then(res => res.json())
                .then(e => {

                    if (e.mensaje === 'ok') {
                        document.getElementById('nombre').value = ''
                        document.getElementById('comentario').value = ''

                        ul.insertAdjacentHTML('afterbegin', `<li id="li${e.id}" class="mb-3"><b>${formdata.get('nombre')}</b> ( ${formdata.get('comentario')})    <input onclick="completado(${e.id})" id="${e.id}" type="checkbox" name="completado"> <a style="margin-left: 20PX;" href="?eliminar=${e.id}">......X......</a>   </li>`)

                    }
                })
                .catch(error => alert(error))
        })


        // COMPLETADO
        function completado(id) {

            var completadoInput = document.getElementById(id)
            var li = document.getElementById(`li${id}`)

            // se marco como completado
            if (completadoInput.checked) {

                let formdataCompletado = new FormData()
                formdataCompletado.append('completado', 1)
                formdataCompletado.append('id_miscosas', id)

                fetch('insertarCosa.php', {
                        method: 'POST',
                        body: formdataCompletado
                    })
                    .then(res => res.json())
                    .then(e => {

                        if (e.mensaje === 'ok completado') {
                            completadoInput.style.display = 'none'
                            li.style.color = 'green'
                        }


                    })
            }



        }
    </script>
</body>

</html>