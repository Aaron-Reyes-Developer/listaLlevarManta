<?php

include('conexion.php');

$respuesta = array('mensaje' => 'ESTAMOS DENTRO', 'id' => '');


//////////////////      INSERTA     //////////////////////
if (isset($_POST['nombre'])) {

    $nombre = $_POST['nombre'];
    $comentario = $_POST['comentario'];


    $queryInsertar = mysqli_query($conn, "INSERT INTO miscosas (nombre, comentario) VALUES ('$nombre', '$comentario') ");

    if ($queryInsertar >= 1) {

        $queryConsulta = mysqli_query($conn, "SELECT * FROM miscosas WHERE nombre = '$nombre' AND  comentario = '$comentario' ");
        $recorrerConsulta = mysqli_fetch_array($queryConsulta);

        $id_cosas = $recorrerConsulta['id_miscosas'];

        $respuesta['mensaje'] = 'ok';
        $respuesta['id'] = $id_cosas;
    }
}



//////////////////      ACTILIZAR COMPLETADO     //////////////////////
if (isset($_POST['completado'])) {

    $completado = $_POST['completado'];
    $id_completado = $_POST['id_miscosas'];

    $queryCompletado = mysqli_query($conn, "UPDATE miscosas SET completado = '1' WHERE id_miscosas = '$id_completado' ");

    if ($queryCompletado >= 1) {
        $respuesta['mensaje'] = 'ok completado';
    }
}

echo json_encode($respuesta);
