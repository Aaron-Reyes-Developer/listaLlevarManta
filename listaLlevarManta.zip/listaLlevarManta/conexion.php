<?php

$server = 'localhost';
$usuario = 'root';
$contra = '';
$bd = 'todo';

$conn = mysqli_connect($server, $usuario, $contra, $bd);
